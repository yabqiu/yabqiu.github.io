<title>Why Log4j can't work in WAS?</title>

<%
    String method = request.getMethod();
    String submit = request.getParameter("submit");
    if(method.equalsIgnoreCase("post")){
    	if("Print Log".equals(submit)){
    		//call TestLog.main() to write log
    		com.unmi.TestLog.main(null);
    		out.println("Output log message: <font color=blue>"+request.getParameter("msg")+"</font>");
    	}else if("Which Class".equals(submit)){
    		out.println("<div style='color:blue'>Where to load the class: "+
    				request.getParameter("cls") + "</div>");
    		out.println("<div style='word-break:break-all;width:700px'>"+
    		        com.unmi.JWhich.which(request.getParameter("cls")).replaceAll("\n","<br>")+
    		        "</div>");
    		out.println("<br>");
    	}
    }
%>

<form method="post">
<table>
	<tr>
		<td>Log Message:</td>
		<td><input name="msg" style="width:400"></td>
		<td><input type="submit" name="submit" value="Print Log" style="width:110"></td>
	</tr>
    <tr>
        <td>Qualified ClassName :</td>
        <td><input name="cls" style="width:400"></td>
        <td><input type="submit" name="submit" value="Which Class" style="width:110"></td>
    </tr>
</table>
</form>