package com.unmi;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class TestLog {

	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Log log = LogFactory.getLog(TestLog.class);
		log.debug("Unmi test commons-logging-log4j.");
	}
}
