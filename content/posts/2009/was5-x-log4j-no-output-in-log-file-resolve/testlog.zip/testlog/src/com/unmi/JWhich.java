package com.unmi;

public class JWhich {

	/**
	 * Prints the absolute pathname of the class file containing the specified
	 * class name, as prescribed by the current classpath.
	 * 
	 * @param className
	 *            Name of the class.
	 */
	public static String which(String className) throws ClassNotFoundException{

		String where = "";
		
		if (!className.startsWith("/")) {
			className = "/" + className;
		}
		className = className.replace('.', '/');
		className = className + ".class";

		java.net.URL classUrl = new JWhich().getClass().getResource(className);

		if (classUrl != null) {
			where = "\nClass '" + className + "' found in \n'"
			        + classUrl.getFile() + "'\n"
			        + "loaded by: \n"
			        + Class.forName(className.replaceAll("^/|(\\.class$)","").replace('/','.')).getClassLoader();
		} else {
			where = "\nClass '" + className + "' not found in \n'"
					+ System.getProperty("java.class.path") + "'";
		}
		
		return where;
	}

	public static void main(String args[]) throws ClassNotFoundException{
		if (args.length > 0) {
			System.out.println(JWhich.which(args[0]));
		} else {
			System.err.println("Usage: java JWhich <classname>");
		}
	}
}