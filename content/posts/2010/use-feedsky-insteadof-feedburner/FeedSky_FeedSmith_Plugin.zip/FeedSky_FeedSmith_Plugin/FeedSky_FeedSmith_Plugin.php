<?php
/*
Plugin Name: FeedSky FeedSmith
Plugin URI: http://unmi.cc
Description: This plugin is dirived from FeedBurner FeedSmith, Modified by Unmi.Originally authored by <a href="http://www.orderedlist.com/">Steve Smith</a>, this plugin detects all ways to access your original WordPress feeds and redirects them to your FeedSky feed so you can track every possible subscriber. 
Author: Unmi
Author URI: http://unmi.cc
Version: 2.3.1
*/

$data = array(
	'feedsky_url'		=> '',
	'feedsky_comments_url'	=> ''
);

$ol_flash = '';

function ol_is_authorized() {
	global $user_level;
	if (function_exists("current_user_can")) {
		return current_user_can('activate_plugins');
	} else {
		return $user_level > 5;
	}
}
								
add_option('feedsky_settings',$data,'FeedSky Feed Replacement Options');

$feedsky_settings = get_option('feedsky_settings');

function fb_is_hash_valid($form_hash) {
	$ret = false;
	$saved_hash = fb_retrieve_hash();
	if ($form_hash === $saved_hash) {
		$ret = true;
	}
	return $ret;
}

function fb_generate_hash() {
	return md5(uniqid(rand(), TRUE));
}

function fb_store_hash($generated_hash) {
	return update_option('feedsmith_token',$generated_hash,'FeedSmith Security Hash');
}

function fb_retrieve_hash() {
	$ret = get_option('feedsmith_token');
	return $ret;
}

function ol_add_feedsky_options_page() {
	if (function_exists('add_options_page')) {
		add_options_page('FeedSky', 'FeedSky', 8, basename(__FILE__), 'ol_feedsky_options_subpanel');
	}
}

function ol_feedsky_options_subpanel() {
	global $ol_flash, $feedsky_settings, $_POST, $wp_rewrite;
	if (ol_is_authorized()) {
		// Easiest test to see if we have been submitted to
		if(isset($_POST['feedsky_url']) || isset($_POST['feedsky_comments_url'])) {
			// Now we check the hash, to make sure we are not getting CSRF
			if(fb_is_hash_valid($_POST['token'])) {
				if (isset($_POST['feedsky_url'])) { 
					$feedsky_settings['feedsky_url'] = $_POST['feedsky_url'];
					update_option('feedsky_settings',$feedsky_settings);
					$ol_flash = "Your settings have been saved.";
				}
				if (isset($_POST['feedsky_comments_url'])) { 
					$feedsky_settings['feedsky_comments_url'] = $_POST['feedsky_comments_url'];
					update_option('feedsky_settings',$feedsky_settings);
					$ol_flash = "Your settings have been saved.";
				} 
			} else {
				// Invalid form hash, possible CSRF attempt
				$ol_flash = "Security hash missing.";
			} // endif fb_is_hash_valid
		} // endif isset(feedsky_url)
	} else {
		$ol_flash = "You don't have enough access rights.";
	}
	
	if ($ol_flash != '') echo '<div id="message" class="updated fade"><p>' . $ol_flash . '</p></div>';
	
	if (ol_is_authorized()) {
		$temp_hash = fb_generate_hash();
		fb_store_hash($temp_hash);
		echo '<div class="wrap">';
		echo '<h2>Set Up Your FeedSky Feed</h2>';
		echo '<p>This plugin makes it easy to redirect 100% of traffic for your feeds to a FeedSky feed you have created. FeedSky can then track all of your feed subscriber traffic and usage and apply a variety of features you choose to improve and enhance your original WordPress feed.</p>
		<form action="" method="post">
		<input type="hidden" name="redirect" value="true" />
		<input type="hidden" name="token" value="' . fb_retrieve_hash() . '" />
		<ol>
		<li>To get started, go here <a href="http://www.feedsky.com" target="_blank">to create a FeedSky feed for ' . get_bloginfo('name') . '</a>. This feed will handle all traffic for your posts.</li>
		<li>Once you have created your FeedSky feed, enter its address into the field below (http://feed.feedsky.com/yourfeed):<br/><input type="text" name="feedsky_url" value="' . htmlentities($feedsky_settings['feedsky_url']) . '" size="45" /></li>
		<li>Optional: If you also want to handle your WordPress comments feed using FeedSky, also follow <a href="http://www.feedsky.com" target="_blank"> to create a FeedSky comments feed</a> and then enter its address below:<br/><input type="text" name="feedsky_comments_url" value="' . htmlentities($feedsky_settings['feedsky_comments_url']) . '" size="45" />
		</ol>
		<p><input type="submit" value="Save" /></p></form>';
		echo '</div>';
	} else {
		echo '<div class="wrap"><p>Sorry, you are not allowed to access this page.</p></div>';
	}

}

function ol_feed_redirect() {
	global $wp, $feedsky_settings, $feed, $withcomments;
	if (is_feed() && $feed != 'comments-rss2' && !is_single() && $wp->query_vars['category_name'] == '' && ($withcomments != 1) && trim($feedsky_settings['feedsky_url']) != '') {
		if (function_exists('status_header')) status_header( 302 );
		header("Location:" . trim($feedsky_settings['feedsky_url']));
		header("HTTP/1.1 302 Temporary Redirect");
		exit();
	} elseif (is_feed() && ($feed == 'comments-rss2' || $withcomments == 1) && trim($feedsky_settings['feedsky_comments_url']) != '') {
		if (function_exists('status_header')) status_header( 302 );
		header("Location:" . trim($feedsky_settings['feedsky_comments_url']));
		header("HTTP/1.1 302 Temporary Redirect");
		exit();
	}
}

function ol_check_url() {
	global $feedsky_settings;
	switch (basename($_SERVER['PHP_SELF'])) {
		case 'wp-rss.php':
		case 'wp-rss2.php':
		case 'wp-atom.php':
		case 'wp-rdf.php':
			if (trim($feedsky_settings['feedsky_url']) != '') {
				if (function_exists('status_header')) status_header( 302 );
				header("Location:" . trim($feedsky_settings['feedsky_url']));
				header("HTTP/1.1 302 Temporary Redirect");
				exit();
			}
			break;
		case 'wp-commentsrss2.php':
			if (trim($feedsky_settings['feedsky_comments_url']) != '') {
				if (function_exists('status_header')) status_header( 302 );
				header("Location:" . trim($feedsky_settings['feedsky_comments_url']));
				header("HTTP/1.1 302 Temporary Redirect");
				exit();
			}
			break;
	}
}

if (!preg_match("/feedsky|feedburner|feedvalidator/i", $_SERVER['HTTP_USER_AGENT']) && $_GET['from'] !='internal') {
	add_action('template_redirect', 'ol_feed_redirect');
	add_action('init','ol_check_url');
}

add_action('admin_menu', 'ol_add_feedsky_options_page');

?>
