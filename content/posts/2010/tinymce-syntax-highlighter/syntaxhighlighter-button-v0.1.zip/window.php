<?php
$wpconfig = realpath("../../../wp-config.php");
if (!file_exists($wpconfig))  {
	echo "Could not found wp-config.php. Error in path :\n\n".$wpconfig ;	
	die;	
}
require_once($wpconfig);
require_once(ABSPATH.'/wp-admin/admin.php');
global $wpdb;
?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>Code Colorer</title>
<!-- 	<meta http-equiv="Content-Type" content="<?php// bloginfo('html_type'); ?>; charset=<?php //echo get_option('blog_charset'); ?>" /> -->
	<script language="javascript" type="text/javascript" src="<?php echo get_option('siteurl') ?>/wp-includes/js/tinymce/tiny_mce_popup.js"></script>
	<script language="javascript" type="text/javascript" src="<?php echo get_option('siteurl') ?>/wp-includes/js/tinymce/utils/form_utils.js"></script>
	<script language="javascript" type="text/javascript" src="<?php echo get_option('siteurl') ?>/wp-content/plugins/syntaxhighlighter-button/tinymce.js"></script>
	<base target="_self" />
</head>
		<body id="link" onload="tinyMCEPopup.executeOnLoad('init();');document.body.style.display='';" style="display: none">
<!-- <form onsubmit="insertLink();return false;" action="#"> -->
	<form name="shtb" action="#">
		<table border="0" cellpadding="4" cellspacing="0">
         <tr>
			<td nowrap="nowrap"><label for="shtb_main"><?php _e("Select Language", 'shtb_main'); ?></label></td>
			<td><select id="shtb_lang" name="shtb_main" style="width: 200px">
				<option value="java">java</option>
				<option value="php">php</option>
 				<option value="c#/c-sharp/csharp">c#/c-sharp/csharp</option>
				<option value="xml/xhtml/xslt/html">xml/xhtml/xslt/html</option>
				<option value="js/jscript/javascript">js/jscript/javascript</option>
				<option value="css">css</option>
				<option value="sql">sql</option>
				<option value="groovy">groovy</option>
				<option value="cpp/c">cpp/c</option>
				<option value="perl/Perl/pl">perl/Perl/pl</option>
				<option value="bash/shell">bash/shell</option>
				<option value="scala">scala</option>
				<option value="vb/vbnet">vb/vbnet</option>
				<option value="py/python">py/python</option>
				<option value="jfx/javafx">jfx/javafx</option>
				<option value="text/plain">text/plain</option>
				<option value="ruby/rails/ror/rb">ruby/rails/ror/rb</option>
				<option value="f#/f-sharp/fsharp">f#/f-sharp/fsharp</option>
				<option value="erl/erlang">erl/erlang</option>
				<option value="powershell/ps">powershell/ps</option>
				<option value="objc/obj-c">objc/obj-c</option>
				<option value="diff/patch">diff/patch</option>
				<option value="delphi/pascal/pas">delphi/pascal/pas</option>
				<option value="coldfusion/cf">coldfusion/cf</option>
				<option value="actionscript3/as3">actionscript3/as3</option>
				<option value="latex/tex">latex/tex</option>
				<option value="matlabkey/matlab">matlabkey/matlab</option>
            </select></td>
          </tr>
          <tr>
			<td nowrap="nowrap" valign="top"><label for="showtype"><?php _e("Show Line Number", 'shtb_main'); ?></label></td>
            <td><label><input name="showtype" id='shtb_linenumbers' type="checkbox" checked="checked" /></label></td>
          </tr>
        </table>
	<div class="mceActionPanel">
		<div style="float: left">
			    <input type="button" id="cancel" name="cancel" value="<?php _e("Cancel", 'shtb_main'); ?>" onclick="tinyMCEPopup.close();" />
		</div>

		<div style="float: right">
				<input type="submit" id="insert" name="insert" value="<?php _e("Insert", 'shtb_main'); ?>" onclick="insertShTag();" />
		</div>
	</div>
</form>
</body>
</html>