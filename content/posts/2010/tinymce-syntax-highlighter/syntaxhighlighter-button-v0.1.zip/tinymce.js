function init() {
	tinyMCEPopup.resizeToInnerSize();
}

function getCheckedValue(radioObj) {
	if(!radioObj)
		return "";
	var radioLength = radioObj.length;
	if(radioLength == undefined)
		if(radioObj.checked)
			return radioObj.value;
		else
			return "";
	for(var i = 0; i < radioLength; i++) {
		if(radioObj[i].checked) {
			return radioObj[i].value;
		}
	}
	return "";
}

function insertShTag() {

	var tagtext;
	var langname_ddb = document.getElementById('shtb_lang');
	var langname = langname_ddb.value.split('/')[0];
	var linenumbers = document.getElementById('shtb_linenumbers').checked;
	var inst = tinyMCE.getInstanceById('content');
	var html = inst.selection.getContent();

	if (linenumbers)
		tagtext = "<pre class='brush:" + langname + "' ";
	else
		tagtext = "<pre class='brush:" + langname + ";gutter:false'";

	if(html.length != 0)
		window.tinyMCE.execInstanceCommand('content', 'mceInsertContent', false, tagtext+'>'+html+'</pre>');
	else
		window.tinyMCE.execInstanceCommand('content', 'mceInsertContent', false, tagtext+'>'+'CodeHere'+'</pre>');
	tinyMCEPopup.editor.execCommand('mceRepaint');
	tinyMCEPopup.close();
	return;
}
