=== Plugin Name ===
Contributors: Unmi
Donate link: http://unmi.cc/
Tags: codecolorer, code, tinymce, button
Requires at least: 2.7
Tested up to: 3.0.1

This plugin was developed for another plugin - SyntaxHighlighter Evolved
 (http://wordpress.org/extend/plugins/syntaxhighlighter/), but easily can be rewrited to another Google syntax highlighting plugin.

== Description ==

This plugin was developed for another plugin - SyntaxHighlighter Evolved
 (http://wordpress.org/extend/plugins/syntaxhighlighter/), but easily can be rewrited to another Google syntax highlighting plugin.


NOTE: It is important that folder of plugin was named as "syntax-button" 

== Installation ==

1. Upload plugin folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Use new button in TinyMCE panel

== Screenshots ==

1. This is a new button on panel
2. This is whot happend if you press it