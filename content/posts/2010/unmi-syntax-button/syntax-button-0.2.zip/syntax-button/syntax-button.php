<?php
/*
Plugin Name:Unmi's Syntax TinyMCE Button
Plugin URI: http://unmi.cc/
Description: Provide a configurable button for TinyMCE, and gave you more flexiable options. Generate <pre class=..>Code here</pre> in Visual mode
Version: 0.2 
Author: Unmi, fantasia@sina.com	
Author URI:  http://unmi.cc
*/
function shtb_addbuttons() {
	// Add only in Rich Editor mode
	if ( get_user_option('rich_editing') == 'true') {
	// add the button for wp25 in a new way
		add_filter("mce_external_plugins", "add_shtb_tinymce_plugin", 5);
		add_filter('mce_buttons', 'register_shtb_button', 5);
	}
}

// used to insert button in wordpress 2.5x editor
function register_shtb_button($buttons) {
	array_push($buttons, "separator", "shtb");
	return $buttons;
}

// Load the TinyMCE plugin : editor_plugin.js (wp2.5)
function add_shtb_tinymce_plugin($plugin_array) {
	$plugin_array['shtb'] = plugins_url('syntax-button/editor_plugin.js');	
	return $plugin_array;
}

function shtb_change_tinymce_version($version) {
	return ++$version;
}

// Modify the version when tinyMCE plugins are changed.
add_filter('tiny_mce_version', 'shtb_change_tinymce_version');
// init process for button control
add_action('init', 'shtb_addbuttons');

//add aditinal css for the tinyMCE Editor
function append_editor_css($css) {  
	return plugins_url('syntax-button/editor_style.css');
} 

add_filter("mce_css", "append_editor_css");
?>