// Docu : http://wiki.moxiecode.com/index.php/TinyMCE:Create_plugin/3.x#Creating_your_own_plugins

(function() {
	
	// Load plugin specific language pack
	tinymce.PluginManager.requireLangPack('shtb');
	
	var g_url;

	var common_brushes = ['java','php','c#/c-sharp/csharp','xml/xhtml/xslt/html','js/jscript/javascript','css','sql','groovy','cpp/c','perl/Perl/pl','bash/shell','py/python','text/plain','jfx/javafx'];
	var other_brushes = ['scala','vb/vbnet','ruby/rails/ror/rb','f#/f-sharp/fsharp','erl/erlang','powershell/ps','objc/obj-c','diff/patch','delphi/pascal/pas','coldfusion/cf','actionscript3/as3','latex/tex','matlabkey/matlab','sass/scss','clojure/Clojure/clj','r/s/splus'];
	

	// Creates a new plugin class and a custom listbox
	tinymce.create('tinymce.plugins.shtb', {
	
		init : function(ed, url) {
			// Register the command so that it can be invoked by using tinyMCE.activeEditor.execCommand('mceExample');
			g_url = url;

			// Register Syntax Highlighter Button
			ed.addButton('shtb', {
				title : 'Syntax Highlighter',
				cmd : 'shtb',
				image : url + '/shtb_img.png'
			});

			// Add a node change handler, selects the button in the UI when a image is selected
			ed.onNodeChange.add(function(ed, cm, n) {
				cm.setActive('shtb', n.nodeName == 'IMG');
			});
		},

		createControl: function(n, cm) {
			switch (n) {
				case 'shtb':
					var c = cm.createMenuButton('unmienubutton', {
						title : 'Syntax Highlighter',
						image : g_url + '/shtb_img.png',
						icons : false
					});

					c.onRenderMenu.add(function(c, m) {
						var sub;

						sub = m.addMenu({title : 'Others'});
		
						for(var i=0;i<other_brushes.length;i++){
							sub.add({title : other_brushes[i], onclick : function() {
								insertShTag(this.title);
							}});
						}

						for(var i=0;i<common_brushes.length;i++){
							m.add({title : common_brushes[i], onclick : function() {
								insertShTag(this.title);
							}});
						}

					});

					// Return the new menu button instance
					return c;
			}

			return null;
		},
	
		getInfo : function() {
			return {
					longname  : "Unmi's SyntaxHilighter Button",
					author 	  : 'Unmi',
					authorurl : 'http://unmi.cc',
					infourl   : 'http://unmi.cc',
					version   : "v0.2"
			};
		}
	});

	// Register plugin with a short name
	tinymce.PluginManager.add('shtb', tinymce.plugins.shtb);

	function insertShTag(language_name) {
		var tagtext;
		var langname = language_name.split('/')[0];
		var inst = tinyMCE.getInstanceById('content');
		var html = inst.selection.getContent();

		tagtext = "<pre class='brush:" + langname + "' ";

		if(html.length != 0)
			window.tinyMCE.execInstanceCommand('content', 'mceInsertContent', false, tagtext+'>'+html+'</pre>');
		else
			window.tinyMCE.execInstanceCommand('content', 'mceInsertContent', false, tagtext+'>' + langname +' CodeHere'+'</pre>');
		return;
	}

})();