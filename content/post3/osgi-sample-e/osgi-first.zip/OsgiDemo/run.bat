@echo off
java -jar org.eclipse.osgi_3.5.2.R35x_v20100126.jar -console