package com.unmi.login.activator;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

import com.unmi.login.service.Validator;
import com.unmi.login.service.impl.LdapValidatorImpl;

public class Activator implements BundleActivator {
	
	private ServiceRegistration serviceReg=null;
	
	// start �� LdapValidatorBundle ʱִ��
	public void start(BundleContext context) throws Exception {
		System.out.println("���� LdapValidatorBundle.");
		serviceReg=context.registerService(Validator.class.getName()
				, new LdapValidatorImpl(), null);
	}

	// stop �� LdapValidatorBundle ʱִ��
	public void stop(BundleContext context) throws Exception {
		System.out.println("ֹͣ LdapValidatorBundle.");
		if(serviceReg!=null){
			serviceReg.unregister();
		}
	}
}
