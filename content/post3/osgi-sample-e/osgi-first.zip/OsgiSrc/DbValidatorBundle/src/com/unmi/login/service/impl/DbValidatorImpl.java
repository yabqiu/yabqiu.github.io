package com.unmi.login.service.impl;

import com.unmi.login.service.Validator;

public class DbValidatorImpl implements Validator {

	@Override
	public boolean validate(String username, String password) throws Exception {
		System.out.println("ʹ�����ݿ���е�½��֤");
		if("Unmi".equalsIgnoreCase(username) && "1234".equals(password)){
			return true;
		}else{
			return false;
		}
	}
}
