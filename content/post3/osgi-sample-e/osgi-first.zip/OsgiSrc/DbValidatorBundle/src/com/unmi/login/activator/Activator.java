package com.unmi.login.activator;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

import com.unmi.login.service.Validator;
import com.unmi.login.service.impl.DbValidatorImpl;

public class Activator implements BundleActivator {

	private ServiceRegistration serviceReg;
	
	// start �� DbValidatorBundle ʱִ��
	public void start(BundleContext context) throws Exception {
		System.out.println("���� DbValidatorBundle.");
		serviceReg = context.registerService(Validator.class.getName(), new DbValidatorImpl(), null);
	}

	// stop ��  DbValidatorBundle ʱִ��
	public void stop(BundleContext context) throws Exception {
		System.out.println("ֹͣ DbValidatorBundle.");
		if(serviceReg!=null){
			serviceReg.unregister();
		}
	}

}
