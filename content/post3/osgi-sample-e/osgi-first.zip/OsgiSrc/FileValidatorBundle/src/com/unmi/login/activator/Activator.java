package com.unmi.login.activator;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

import com.unmi.login.service.Validator;
import com.unmi.login.service.impl.FileValidatorImpl;

public class Activator implements BundleActivator {
	
	private ServiceRegistration serviceReg=null;
	
	// start ��  FileValidatorBundle ʱִ��
	public void start(BundleContext context) throws Exception {
		System.out.println("���� FileValidatorBundle.");
		serviceReg=context.registerService(Validator.class.getName(), new FileValidatorImpl(), null);
	}

	// stop ��  FileValidatorBundle ʱִ��
	public void stop(BundleContext context) throws Exception {
		System.out.println("ֹͣ FileValidatorBundle.");
		if(serviceReg!=null){
			serviceReg.unregister();
		}
	}
}
