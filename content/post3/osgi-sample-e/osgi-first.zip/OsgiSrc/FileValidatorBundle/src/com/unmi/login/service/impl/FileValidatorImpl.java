package com.unmi.login.service.impl;

import com.unmi.login.service.Validator;

public class FileValidatorImpl implements Validator {

	@Override
	public boolean validate(String username, String password) throws Exception {
		System.out.println("ʹ�������ļ����е�½��֤");
		if("Unmi".equalsIgnoreCase(username) && "1234".equals(password)){
			return true;
		}else{
			return false;
		}
	}
}
