<%@ page language="java" pageEncoding="UTF-8"%>
<%@ taglib uri="http://struts.apache.org/tags-bean" prefix="bean"%>
<%@ taglib uri="http://struts.apache.org/tags-html" prefix="html"%>
<%@ taglib uri="http://struts.apache.org/tags-html" prefix="nested"%>

<script type="text/javascript" src="js/public.js"></script>

<%@ page contentType="text/html; charset=UTF-8"%>
<html:html>
<head>
	<style type="text/css">
	BODY,TD {FONT-FAMILY: "宋体"; FONT-SIZE: 10pt;line-height: 15px} 
	</style>
	<title>持有股票</title>
</head>
<body><br>
	<html:form action="/showStock">
		<h3>记录持有的股票<br></h3>
		<fieldset><legend>基本信息</legend>
		<table width="100%" border=0><tr>
			<td>帐户名:<html:text property="account.name"/></td>
			<td>资金帐号:<html:text property="account.number"/></td>
		</tr></table>
		</fieldset>
		<br>
		<fieldset><legend>持有股票</legend>
		<table width=100% border=0 id="stockTable">
		<tr>
			<td><input type="checkbox" onclick="checkAll(this)"></td>
			<td>股票代码</td>
			<td>股票名称</td>
			<td>成本价</td>
			<td>股票数量</td>
		</tr>
		<tr>
			<td><input type="checkbox" name="check"></td>
			<td><input name="stocks[0].code" size="15"></td>
			<td><input name="stocks[0].name" size="15"></td>
			<td><input name="stocks[0].price" size="15"></td>
			<td><input name="stocks[0].quantity" size="15"></td>
		</tr>
		<tr>
			<td><input type="checkbox" name="check"></td>
			<td><input name="stocks[1].code" size="15"></td>
			<td><input name="stocks[1].name" size="15"></td>
			<td><input name="stocks[1].price" size="15"></td>
			<td><input name="stocks[1].quantity" size="15"></td>
		</tr>
		</table>
		<table width="100%" border="0">
		<tr>
			<td width="20">&nbsp;</td>
			<td><input type="button" value="添加行" onclick="insertRow()">
				<input type="button" value="删除行" onclick="deleteRow()"></td>
			<td colspan="2">&nbsp;</td>
		</tr>
		</table>
		</fieldset>
		<br>
		<div align="right"><html:submit onclick="resetIndex()">保存数据</html:submit></div>
	</html:form>
</body>
</html:html>
