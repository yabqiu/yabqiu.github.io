<%@ page language="java" pageEncoding="UTF-8"%>
<%@ taglib uri="http://struts.apache.org/tags-bean" prefix="bean"%>
<%@ taglib uri="http://struts.apache.org/tags-html" prefix="html"%>
<%@ taglib uri="http://struts.apache.org/tags-nested" prefix="nested"%>

<script type="text/javascript" src="js/public.js"></script>

<%@ page contentType="text/html; charset=UTF-8"%>
<html:html>
<head>
	<style type="text/css">
	BODY,TD {FONT-FAMILY: "宋体"; FONT-SIZE: 10pt;line-height: 15px} 
	</style>
	<title>持有股票</title>
</head>
<body><br>
	<html:form action="/showStock">
		<h3>修改持有的股票<br></h3>
		<fieldset><legend>基本信息</legend>
		<table width="100%" border=0><tr>
		<nested:nest property="account">
			<td>帐户名:<nested:text property="name" readonly="true"/></td>
			<td>资金帐号:<nested:text property="number" readonly="true"/></td>
		</nested:nest>
		</tr></table>
		</fieldset>
		<br>
		<fieldset><legend>持有股票</legend>
		<table width=100% border=0  id="stockTable">
		<tr>
			<td><input type="checkbox" onclick="checkAll(this)"></td>
			<td>股票代码</td>
			<td>股票名称</td>
			<td>成本价</td>
			<td>股票数量</td>
		</tr>
		<nested:iterate id="stock" property="stocks">
		<tr>
			<td><input type="checkbox" name="check"></td>
			<td><nested:text property="code" size="15"/></td>
			<td><nested:text property="name" size="15"/></td>
			<td><nested:text property="price" size="15"/></td>
			<td><nested:text property="quantity" size="15"/></td>
		</tr>
		</nested:iterate>
		</table>
		<table width="100%" border="0">
		<tr>
			<td width="21">&nbsp;</td>
			<td><input type="button" value="添加行" onclick="insertRow()">
				<input type="button" value="删除行" onclick="deleteRow()"></td>
		</tr>
		</table>
		</fieldset>
		<br>

		<div align="right"><html:submit>修改数据</html:submit></div>
		
	</html:form>

</body>
</html:html>
