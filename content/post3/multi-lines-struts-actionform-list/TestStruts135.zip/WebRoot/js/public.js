//插入表格行
function insertRow()
{
	var stockTable = document.getElementById("stockTable");
	var newRow = stockTable.insertRow();
	var cell1 = newRow.insertCell();
	cell1.innerHTML = '<input type="checkbox" name="check">';
	var cell2 = newRow.insertCell();
	cell2.innerHTML = '<input name="stocks[0].code" size="15">';
	var cell3 = newRow.insertCell();
	cell3.innerHTML = '<input name="stocks[0].name" size="15">';
	var cell4 = newRow.insertCell();
	cell4.innerHTML = '<input name="stocks[0].price" size="15">';
	var cell5 = newRow.insertCell();
	cell5.innerHTML = '<input name="stocks[0].quantity" size="15">';
}

//删除表格行
function deleteRow()
{
	var stockTable = document.getElementById("stockTable");
	var checks = document.getElementsByName("check");
	for(var i=checks.length-1;i>=0;i--)
	{
		if(checks[i].checked)
		{
			var index =checks[i].parentNode.parentNode.rowIndex;
			stockTable.deleteRow(index);
		}
	}
}

//重置索引
function resetIndex()
{
	var inputs = document.getElementsByTagName("input");
	for(var i=0;i<inputs.length;i++)
	{
		if(inputs[i].name.indexOf('stocks[')!=-1)
		{
			var index =inputs[i].parentNode.parentNode.rowIndex;
			inputs[i].name = inputs[i].name.replace(/\d+/,index-1);
		}
	}
}

//全选
function checkAll(obj)
{
	var checks = document.getElementsByName("check");
	for(var i=checks.length-1;i>=0;i--)
	{
		checks[i].checked = obj.checked;
	}
}