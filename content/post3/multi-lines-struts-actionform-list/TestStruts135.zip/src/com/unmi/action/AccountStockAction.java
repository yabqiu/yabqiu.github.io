package com.unmi.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.unmi.bean.Account;
import com.unmi.bean.Stock;
import com.unmi.form.AccountStockForm;

public class AccountStockAction extends Action
{

    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        AccountStockForm asForm = (AccountStockForm)form;
        
        Account account = asForm.getAccount();
        System.out.println("Account Name:"+account.getName()+
                " Number:"+account.getNumber());
        
        List stocks = asForm.getStocks();
        for (int i=0; i<stocks.size() ;i++)
        {
            Stock stock = (Stock)stocks.get(i);
            System.out.println("Stock["+i+"]Code:"+stock.getCode()+
                    " Name:"+stock.getName()+
                    " Price:"+stock.getPrice()+
                    " Quantity:"+stock.getQuantity());
        }
        
        return mapping.findForward("show");
    }
}
