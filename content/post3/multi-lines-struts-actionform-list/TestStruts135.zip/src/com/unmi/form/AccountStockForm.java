package com.unmi.form;

import java.util.List;

import org.apache.struts.action.ActionForm;

import com.unmi.bean.Account;
import com.unmi.bean.AutoArrayList;
import com.unmi.bean.Stock;

public class AccountStockForm extends ActionForm
{
    private Account account = new Account();
    private List stocks = new AutoArrayList(Stock.class);
    
    public void setStocks(List stocks)
    {
        this.stocks.clear();
        this.stocks.addAll(stocks);
    }


    public List getStocks()
    {
        return stocks;
    }


    public Account getAccount()
    {
        return account;
    }

    public void setAccount(Account account)
    {
        this.account = account;
    }
}
